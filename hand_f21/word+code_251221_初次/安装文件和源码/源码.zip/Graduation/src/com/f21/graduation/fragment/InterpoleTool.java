package com.f21.graduation.fragment;

public class InterpoleTool {
	public static class ConstantsHolder{
		/** 源图像的宽度 */
		static float widthOrigin;
		/** 源图像的高度 */
		static float heightOrigin;
		
		/** 目标图像的宽度 */
		static float widthTarget;
		/** 目标图像的高度 */
		static float heightTarget;
	}
	
	private class VariableHolder{
		/** 源图像与目标图像宽的比例 */
		float widthScale = (ConstantsHolder.widthOrigin - 1) / (ConstantsHolder.widthTarget - 1);
		/** 源图像与目标图像高的比例 */
		float heightScale = (ConstantsHolder.heightOrigin - 1) / (ConstantsHolder.heightTarget - 1);
	}

	
}
