package com.f21.graduation.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;

import com.f21.graduation.R;
import com.f21.graduation.fragment.PlaceholderFragment;
import com.lib.base.BaseFragmentActivity;

public class MainActivity extends BaseFragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
        	FragmentTransaction transaction =  getSupportFragmentManager().beginTransaction();
        	transaction.add(R.id.container, new PlaceholderFragment());
        	transaction.commit();
        }
    }
}
