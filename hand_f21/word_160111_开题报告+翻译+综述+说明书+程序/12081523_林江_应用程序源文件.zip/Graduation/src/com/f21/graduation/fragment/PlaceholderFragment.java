package com.f21.graduation.fragment;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.f21.graduation.R;
import com.lib.base.BaseFragment;
import com.lib.z.utils.object.KeyBoardUtils;
import com.lib.z.utils.object.ToastUtils;

public class PlaceholderFragment extends BaseFragment{
	private View rootView;
	private ViewHolder mHolder;
	private class ViewHolder{
		EditText inputET;
		Button setBTN;
		SeekBar scaleSB;
		TextView stateTV;
		ImageView showPicIV;
	}
	private Matrix mMatrix;
	private Bitmap bitmap;
	private float scaleX = 1.0f;	// 初始比例
	private float scaleY = 1.0f;	// 初始比例
	private final int BASE_SCALE = 255;  // 表示seekbar最大数
	private final float maxScale = 4.0f;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = inflater.inflate(R.layout.fragment_main, container, false);
		return rootView;
	}

	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);

		initView();
		initData();
		
		mHolder.scaleSB.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				scaleX = maxScale * seekBar.getProgress() / BASE_SCALE;
				scaleY = maxScale * seekBar.getProgress() / BASE_SCALE;
				bitmapScale(scaleX, scaleY);
				showStateTv(scaleX, scaleY);
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				
			}
		});
		
		mHolder.setBTN.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String input = mHolder.inputET.getText().toString().trim();
				float size = Float.parseFloat(input);
				if (size < 0 || size > maxScale) {
					ToastUtils.show(getActivity(),"输入值请勿超过最大值或低于0");
				}else {
					showStateTv(size, size);
					mHolder.scaleSB.setProgress((int)(size*BASE_SCALE/maxScale));
					bitmapScale(size, size);
					
					KeyBoardUtils.closeKeybord(mHolder.inputET, getActivity());
					mHolder.inputET.setText("");
				}
			}
		});
	}

	/**
	 * 初始化控件
	 */
	private void initView(){
		mHolder = new ViewHolder();
		mHolder.inputET = (EditText) rootView.findViewById(R.id.et_input);
		mHolder.setBTN = (Button) rootView.findViewById(R.id.btn_set);
		mHolder.scaleSB = (SeekBar) rootView.findViewById(R.id.sb_scale);
		mHolder.stateTV = (TextView) rootView.findViewById(R.id.tv_state);
		mHolder.showPicIV = (ImageView) rootView.findViewById(R.id.iv_show_pic);

		mMatrix = new Matrix();
		bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.show);
	}
	
	/**
	 * 初始化比例为1
	 */
	private void initData() {
		showStateTv(1.0f, 1.0f);
		mHolder.scaleSB.setProgress((int)(BASE_SCALE/maxScale));
		bitmapScale(scaleX, scaleY);
	}
	
	/**
	 * 缩放图片
	 * @param x	X比例
	 * @param y	Y比例
	 */
	protected void bitmapScale(float x, float y) {
		Bitmap afterBitmap = Bitmap.createBitmap(bitmap.getWidth(),bitmap.getHeight(),bitmap.getConfig());
		Canvas canvas = new Canvas(afterBitmap);
		mMatrix.setScale(x, y, bitmap.getWidth()/2, bitmap.getHeight()/2);
		canvas.drawBitmap(bitmap, mMatrix, new Paint());

		mHolder.showPicIV.setImageBitmap(afterBitmap);
	}
	
	/**
	 * 修改 显示
	 * @param scaleX
	 * @param scaleY
	 */
	private void showStateTv(float scaleX, float scaleY){
		mHolder.stateTV.setText("scaleX = " + scaleX + "\n" + "scaleY = " + scaleY + "\t\tMaxScale = " + maxScale);
	}
}



















